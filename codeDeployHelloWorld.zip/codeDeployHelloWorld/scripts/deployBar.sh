#!/usr/bin/env bash

set -ex

# source /Users/sher/tmp/codeDeploy/creds.sh
source /home/ec2-user/creds.sh


##
## Create token
##
curl -s --request POST \
  --url "${hostname}/api/v1/tokens" \
  --header 'Content-Type: application/json' \
  --header "X-IBM-Client-Id: ${clientId}" \
  --header "X-IBM-Client-Secret: ${clientSecret}" \
  --header "x-ibm-instance-id: ${instanceId}" \
  --data "{
  \"apiKey\": \"${apiKey}\"
}" | jq -r '.access_token' > /tmp/appconnect_token.txt

export appConnToken=$(cat /tmp/appconnect_token.txt)
echo $appConnToken

##
## Upload Bar file
##
export bar_url=$(curl -s --request PUT \
  --url "${hostname}/api/v1/bar-files/CustomerDatabaseV1" \
  --header "Authorization: Bearer ${appConnToken}" \
  --header 'Content-Type: application/octet-stream' \
  --header "X-IBM-Client-Id: ${clientId}" \
  --data-binary @/home/ec2-user/CustomerDatabaseV1.bar | jq -r '.url')

#   --data-binary @/Users/sher/tmp/codeDeploy/codeDeployHelloWorld/CustomerDatabaseV1.bar | jq -r '.url')


##
## Deploy Bar file to an Integration Runtime
##

# irCrFilePath="/Users/sher/tmp/codeDeploy/codeDeployHelloWorld/irCr.json"
irCrFilePath="/home/ec2-user/irCr.json"

export irCr=$(jq --arg barUrl $bar_url '.spec.barURL[0] = $barUrl' $irCrFilePath)
export irName=$(jq -r '.metadata.name' $irCrFilePath)


curl --request PUT \
  --url "${hostname}/api/v1/integration-runtimes/${irName}" \
  --header "Authorization: Bearer ${appConnToken}" \
  --header 'Content-Type: application/json' \
  --header "X-IBM-Client-Id: ${clientId}" \
  --data "$irCr"

exit 0